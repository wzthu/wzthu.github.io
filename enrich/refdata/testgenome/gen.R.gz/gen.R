re <- read.table("RE_gene_corr.bed",sep='\t',header=FALSE)
enhance <- read.table("Enhancer_RE_gene_corr.bed",sep='\t',header=FALSE)
allre <- unique(c(as.character(enhance$V4),as.character(re$V4)))
motifTF<-get(load("MotifTFTable.RData"))
motif <- get(load("MotifWeights.RData"))
TFgene <- get(load("TFgeneRelMtx.RData"))

mergers <- merge(motifTF,data.frame(tfName = allre),on=tfName)

mergers <- mergers[,c("motifName", "tfName")]

allmotif <- unique(as.character(mergers$motifName))

allmotif <- allmotif[(1:length(allmotif))%%5==0]

tfGeneRelMtx <- TFgene[allmotif,allre]

motifWeights <- merge(data.frame(motifName=allmotif),motif,on=motifName)
motifTFTable <- mergers

save(tfGeneRelMtx,file = "TFgeneRelMtx.RData")
save(motifWeights,file = "MotifWeights.RData")
save(motifTFTable,file = "MotifTFTable.RData")

con <- file("all_motif_rmdup", "r")
lines <- readLines(con)
close(con)

writelines <- c()
flag = FALSE
for(line in lines){
    if(substring(line, 1, 1) == ">"){
        strlist <- unlist(unlist(strsplit(subring(line,2),"\t")))
        exseq <- strlist[1]
        motifName <- strlist[2]
        threshold <- strlist[3]
        if(motifName %in% as.character(motifWeights$motifName)){
            flag = TRUE
            writelines <- c(writelines,line)
        }else{
            flag = FALSE
        }
    }else if(flag){
        writelines <- c(writelines,line)
    }
}

writeLines(writelines,con = "all_motif_rmdup")




